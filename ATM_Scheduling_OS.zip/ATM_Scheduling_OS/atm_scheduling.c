#include <stdio.h>
#include <stdlib.h>

#define MAX_CUSTOMERS 50

// Structure to store customer details
typedef struct
{
    int customer_id;
    int arrival_time;
    int transaction_time;
    int priority;       // 0 = VIP, 1 = Regular
    int remaining_time; // For RR & Preemptive Priority
    int waiting_time;
    int turnaround_time;
} Customer;

void fcfs(Customer customers[], int n)
{
    int current_time = 0;
    float total_waiting_time = 0;
    float total_turnaround_time = 0;

    printf("\n--- FCFS SCHEDULING ---\n");
    printf("ID\tArrival\tBurst\tWaiting\tTurnaround\n");

    for (int i = 0; i < n; i++)
    {
        if (current_time < customers[i].arrival_time)
        {
            current_time = customers[i].arrival_time;
        }

        customers[i].waiting_time = current_time - customers[i].arrival_time;
        customers[i].turnaround_time =
            customers[i].waiting_time + customers[i].transaction_time;

        current_time += customers[i].transaction_time;

        total_waiting_time += customers[i].waiting_time;
        total_turnaround_time += customers[i].turnaround_time;

        printf("%d\t%d\t%d\t%d\t\t%d\n",
               customers[i].customer_id,
               customers[i].arrival_time,
               customers[i].transaction_time,
               customers[i].waiting_time,
               customers[i].turnaround_time);
    }

    printf("\nAverage Waiting Time: %.2f\n",
           total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n",
           total_turnaround_time / n);
}

void priority_preemptive(Customer customers[], int n)
{
    int time = 0, completed = 0;
    int highest_priority_index = -1;
    int min_priority;
    int is_completed[MAX_CUSTOMERS] = {0};

    float total_waiting_time = 0;
    float total_turnaround_time = 0;

    printf("\n--- PREEMPTIVE PRIORITY SCHEDULING (VIP FIRST) ---\n");

    while (completed < n)
    {
        min_priority = 999;
        highest_priority_index = -1;

        for (int i = 0; i < n; i++)
        {
            if (customers[i].arrival_time <= time &&
                !is_completed[i] &&
                customers[i].remaining_time > 0 &&
                customers[i].priority < min_priority)
            {

                min_priority = customers[i].priority;
                highest_priority_index = i;
            }
        }

        if (highest_priority_index == -1)
        {
            time++;
            continue;
        }

        customers[highest_priority_index].remaining_time--;
        time++;

        if (customers[highest_priority_index].remaining_time == 0)
        {
            is_completed[highest_priority_index] = 1;
            completed++;

            customers[highest_priority_index].turnaround_time =
                time - customers[highest_priority_index].arrival_time;

            customers[highest_priority_index].waiting_time =
                customers[highest_priority_index].turnaround_time -
                customers[highest_priority_index].transaction_time;

            total_waiting_time += customers[highest_priority_index].waiting_time;
            total_turnaround_time += customers[highest_priority_index].turnaround_time;
        }
    }

    printf("ID\tPriority\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d\t%d\t\t%d\t\t%d\n",
               customers[i].customer_id,
               customers[i].priority,
               customers[i].waiting_time,
               customers[i].turnaround_time);
    }

    printf("\nAverage Waiting Time: %.2f\n",
           total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n",
           total_turnaround_time / n);
}

void round_robin(Customer customers[], int n, int time_quantum)
{
    int time = 0;
    int completed = 0;
    int queue[MAX_CUSTOMERS];
    int front = 0, rear = 0;

    int visited[MAX_CUSTOMERS] = {0};

    float total_waiting_time = 0;
    float total_turnaround_time = 0;

    // Initially add arrived customers at time 0
    for (int i = 0; i < n; i++)
    {
        if (customers[i].arrival_time == 0)
        {
            queue[rear++] = i;
            visited[i] = 1;
        }
    }

    printf("\n--- ROUND ROBIN SCHEDULING ---\n");

    while (completed < n)
    {
        if (front == rear)
        {
            time++;
            for (int i = 0; i < n; i++)
            {
                if (!visited[i] && customers[i].arrival_time <= time)
                {
                    queue[rear++] = i;
                    visited[i] = 1;
                }
            }
            continue;
        }

        int idx = queue[front++];
        int exec_time =
            customers[idx].remaining_time > time_quantum
                ? time_quantum
                : customers[idx].remaining_time;

        customers[idx].remaining_time -= exec_time;
        time += exec_time;

        for (int i = 0; i < n; i++)
        {
            if (!visited[i] && customers[i].arrival_time <= time)
            {
                queue[rear++] = i;
                visited[i] = 1;
            }
        }

        if (customers[idx].remaining_time > 0)
        {
            queue[rear++] = idx;
        }
        else
        {
            completed++;
            customers[idx].turnaround_time =
                time - customers[idx].arrival_time;
            customers[idx].waiting_time =
                customers[idx].turnaround_time -
                customers[idx].transaction_time;

            total_waiting_time += customers[idx].waiting_time;
            total_turnaround_time += customers[idx].turnaround_time;
        }
    }

    printf("ID\tWaiting\tTurnaround\n");
    for (int i = 0; i < n; i++)
    {
        printf("%d\t%d\t\t%d\n",
               customers[i].customer_id,
               customers[i].waiting_time,
               customers[i].turnaround_time);
    }

    printf("\nAverage Waiting Time: %.2f\n",
           total_waiting_time / n);
    printf("Average Turnaround Time: %.2f\n",
           total_turnaround_time / n);
}

int main()
{
    int choice;
    int n;

    // Dynamic memory allocation for customers
    Customer *customers = (Customer *)malloc(MAX_CUSTOMERS * sizeof(Customer));

    if (customers == NULL)
    {
        printf("Memory allocation failed.\n");
        return 1;
    }

    while (1)
    {
        printf("\n====== BANK ATM SCHEDULING SYSTEM ======\n");
        printf("1. Enter Customer Details\n");
        printf("2. FCFS Scheduling\n");
        printf("3. Priority Scheduling (Preemptive)\n");
        printf("4. Round Robin Scheduling\n");
        printf("5. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice)
        {
        case 1:
            printf("Enter number of customers (max %d): ", MAX_CUSTOMERS);
            scanf("%d", &n);

            for (int i = 0; i < n; i++)
            {
                printf("\nCustomer %d\n", i + 1);
                customers[i].customer_id = i + 1;

                printf("Arrival Time: ");
                scanf("%d", &customers[i].arrival_time);

                printf("Transaction Duration: ");
                scanf("%d", &customers[i].transaction_time);

                printf("Priority (0 = VIP, 1 = Regular): ");
                scanf("%d", &customers[i].priority);

                customers[i].remaining_time = customers[i].transaction_time;
            }
            break;

        case 2:
            fcfs(customers, n);
            break;

        case 3:
            for (int i = 0; i < n; i++)
            {
                customers[i].remaining_time = customers[i].transaction_time;
            }
            priority_preemptive(customers, n);
            break;

        case 4:
        {
            int time_quantum;
            printf("Enter Time Quantum: ");
            scanf("%d", &time_quantum);

            for (int i = 0; i < n; i++)
            {
                customers[i].remaining_time = customers[i].transaction_time;
            }

            round_robin(customers, n, time_quantum);
            break;
        }

        case 5:
            free(customers); // Proper memory deallocation
            printf("Exiting program.\n");
            exit(0);

        default:
            printf("Invalid choice.\n");
        }
    }

    return 0;
}